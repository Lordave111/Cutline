"use client";
import { useEffect, useRef, useState } from "react";
import { SignInButton, useAuth } from "@clerk/nextjs";
import { COST, CURRENCY, PACKS } from "@/lib/pricing";

const MAX_SIDE = 1800;
type Mode = "cutout" | "color" | "image" | "ai";
const MODES: [Mode, string][] = [["cutout", "Transparent"], ["color", "Color"], ["image", "My image"], ["ai", "AI prompt"]];

async function shrink(file: File): Promise<File> {
  const bmp = await createImageBitmap(file);
  const s = Math.min(1, MAX_SIDE / Math.max(bmp.width, bmp.height));
  const c = document.createElement("canvas");
  c.width = Math.round(bmp.width * s); c.height = Math.round(bmp.height * s);
  const x = c.getContext("2d")!;
  x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height);
  x.drawImage(bmp, 0, 0, c.width, c.height);
  const blob = await new Promise<Blob>((r) => c.toBlob((b) => r(b!), "image/jpeg", 0.88));
  return new File([blob], "photo.jpg", { type: "image/jpeg" });
}

async function compose(cut: Blob, bg: { color?: string; image?: File }): Promise<Blob> {
  const fg = await createImageBitmap(cut);
  const c = document.createElement("canvas");
  c.width = fg.width; c.height = fg.height;
  const x = c.getContext("2d")!;
  if (bg.image) {
    const b = await createImageBitmap(bg.image);
    const s = Math.max(c.width / b.width, c.height / b.height);
    x.drawImage(b, (c.width - b.width * s) / 2, (c.height - b.height * s) / 2, b.width * s, b.height * s);
  } else if (bg.color) { x.fillStyle = bg.color; x.fillRect(0, 0, c.width, c.height); }
  x.drawImage(fg, 0, 0);
  return new Promise((r) => c.toBlob((b) => r(b!), "image/png"));
}

async function call(url: string, body: FormData, onLeft: (n: number) => void): Promise<Blob> {
  const r = await fetch(url, { method: "POST", body });
  if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(j.error || "Request failed. Try a smaller image."); }
  const left = r.headers.get("X-Credits-Left");
  if (left) onLeft(Number(left));
  return r.blob();
}

export default function Studio() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [mode, setMode] = useState<Mode>("cutout");
  const [color, setColor] = useState("#0d1117");
  const [bgFile, setBgFile] = useState<File | null>(null);
  const [prompt, setPrompt] = useState("");
  const [out, setOut] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const cut = useRef<{ src: File; blob: Blob } | null>(null);
  const { isSignedIn } = useAuth();
  const [credits, setCredits] = useState<number | null>(null);

  useEffect(() => {
    if (!isSignedIn) { setCredits(null); return; }
    let tries = new URLSearchParams(location.search).has("paid") ? 6 : 1; // after payment, wait for the webhook
    const load = async () => {
      const r = await fetch("/api/credits");
      if (r.ok) setCredits((await r.json()).credits);
      if (--tries > 0) setTimeout(load, 2000);
    };
    load();
  }, [isSignedIn]);

  async function buy(pack: string) {
    setError("");
    const r = await fetch("/api/checkout", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pack }) });
    const j = await r.json().catch(() => ({}));
    if (r.ok && j.url) location.href = j.url; else setError(j.error || "Could not start checkout.");
  }

  async function pick(f?: File) {
    if (!f) return;
    setError(""); setOut("");
    try { const s = await shrink(f); setFile(s); setPreview(URL.createObjectURL(s)); }
    catch { setError("Could not read that image."); }
  }

  async function run() {
    if (!file) return;
    setBusy(true); setError("");
    try {
      let blob: Blob;
      if (mode === "ai") {
        const f = new FormData(); f.append("image", file); f.append("prompt", prompt);
        blob = await call("/api/background", f, setCredits);
      } else {
        if (!cut.current || cut.current.src !== file) {
          const f = new FormData(); f.append("image", file);
          cut.current = { src: file, blob: await call("/api/cutout", f, setCredits) };
        }
        blob = cut.current.blob;
        if (mode === "color") blob = await compose(blob, { color });
        if (mode === "image") {
          if (!bgFile) throw new Error("Upload a background image first.");
          blob = await compose(blob, { image: bgFile });
        }
      }
      setOut(URL.createObjectURL(blob));
    } catch (e) { setError(e instanceof Error ? e.message : "Something went wrong."); }
    finally { setBusy(false); }
  }

  return (
    <section className="studio" id="studio">
      <div className="bar">
        {isSignedIn ? (
          <>
            <span>CREDITS <b>{credits ?? "…"}</b></span>
            <span className="mute">Cut-out {COST.cutout} · AI background {COST.ai}</span>
          </>
        ) : (
          <SignInButton mode="modal"><button className="go">Sign in for free credits</button></SignInButton>
        )}
      </div>
      {isSignedIn && (
        <div className="packs">
          {Object.entries(PACKS).map(([id, p]) => (
            <button key={id} onClick={() => buy(id)}>
              <b>{p.label}</b><span>{p.credits} credits</span><span>{CURRENCY === "NGN" ? "₦" : "$"}{p.price[CURRENCY].toLocaleString()}</span>
            </button>
          ))}
        </div>
      )}
      <label className="drop">
        <input type="file" accept="image/*" hidden onChange={(e) => pick(e.target.files?.[0])} />
        {file ? "Change photo" : "Drop a photo or tap to upload"}
      </label>

      <div className="tabs" role="tablist">
        {MODES.map(([m, label]) => (
          <button key={m} role="tab" aria-selected={mode === m} className={mode === m ? "on" : ""} onClick={() => setMode(m)}>{label}</button>
        ))}
      </div>

      {mode === "color" && <input aria-label="Background color" type="color" value={color} onChange={(e) => setColor(e.target.value)} />}
      {mode === "image" && <input aria-label="Background image" type="file" accept="image/*" onChange={(e) => setBgFile(e.target.files?.[0] ?? null)} />}
      {mode === "ai" && <input aria-label="Describe the background" placeholder="e.g. sunlit marble kitchen counter" maxLength={200} value={prompt} onChange={(e) => setPrompt(e.target.value)} />}

      <button className="go" onClick={run} disabled={!file || busy || !isSignedIn}>{busy ? "Processing…" : "Run"}</button>
      {error && <p className="err" role="alert">{error}</p>}

      <div className="views">
        {preview && <figure><figcaption>INPUT</figcaption><img src={preview} alt="Original" /></figure>}
        {out && (
          <figure><figcaption>OUTPUT</figcaption>
            <div className="checker"><img src={out} alt="Result" /></div>
            <a className="dl" href={out} download="cutline.png">Download PNG</a>
          </figure>
        )}
      </div>
    </section>
  );
}
